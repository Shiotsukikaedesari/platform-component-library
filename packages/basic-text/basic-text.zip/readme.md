## @vis-resm/template-vue2

resm vue2 模板

<p>
  <img alt="license" src="https://img.shields.io/npm/l/@vis-resm/el-button?color=blue">
  <img alt="version" src="https://img.shields.io/npm/v/@vis-resm/el-button?color=light">
  <img alt="downloads" src="https://img.shields.io/npm/dt/@vis-resm/el-button">
</p>
## 项目命令

- 开发：`npm run dev`
- 构建：`npm run build`
- 测试预览：`npm run preview`
- 代码格式化：`npm run lint`
